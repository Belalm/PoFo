# SliderMenu
A simple Menu inspired by SWRevealView Controller and Google Material Menu
![simulator screen shot 24-mar-2017 5 47 41 pm](https://cloud.githubusercontent.com/assets/13949425/24293911/1466de5c-10ba-11e7-84f8-6ef6b272f201.png)



Download the project file and explore 
