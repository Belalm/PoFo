# TwitterAnimation
Twiiter animation with strechty header and tableview cells with differnt type


![](http://i.giphy.com/3oKIPnA0My1vQMIyBy.gif)
