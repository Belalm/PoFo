//
//  DealsCollectionViewCell.swift
//  DemoBuisness
//
//  Created by Saif Chaudhary on 1/23/17.
//  Copyright © 2017 Saif Chaudhary. All rights reserved.
//

import UIKit

class DealsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageViewDeals: UIImageView!
    @IBOutlet weak var labelDealTitle: UILabel!
    @IBOutlet weak var labelTime: UILabel!
    @IBOutlet weak var labelCutDiscount: UILabel!
    @IBOutlet weak var labelDiscount: UILabel!
    
}
